using Microsoft.VisualStudio.Text;
using Microsoft.VisualStudio.Text.Editor;
using Microsoft.VisualStudio.Text.Formatting;
using Microsoft.VisualStudio.Text.Tagging;
using Microsoft.VisualStudio.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace RenderDocComments.DocCommentRenderer
{
    // ── Tag ──────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Margin glyph tag — one per doc-comment block first line.
    /// Carries the block span so the glyph knows which block to toggle.
    /// </summary>
    internal sealed class DocCommentGlyphTag : IGlyphTag
    {
        public SnapshotSpan BlockSpan { get; }
        public DocCommentGlyphTag(SnapshotSpan blockSpan) { BlockSpan = blockSpan; }
    }

    // ── Tagger ───────────────────────────────────────────────────────────────────

    /// <summary>
    /// Emits <see cref="DocCommentGlyphTag"/> on the first line of each doc-comment
    /// block when the Pro glyph toggle feature is enabled.
    /// </summary>
    internal sealed class DocCommentGlyphTagger : ITagger<DocCommentGlyphTag>, IDisposable
    {
        private readonly ITextBuffer _buffer;
        public event EventHandler<SnapshotSpanEventArgs> TagsChanged;

        private static readonly System.Text.RegularExpressions.Regex DocLineRegex =
            new System.Text.RegularExpressions.Regex(@"^\s*///", System.Text.RegularExpressions.RegexOptions.Compiled);

        public DocCommentGlyphTagger(ITextBuffer buffer)
        {
            _buffer = buffer;
            _buffer.Changed += OnBufferChanged;
            SettingsChangedBroadcast.SettingsChanged += OnSettingsChanged;
        }

        public IEnumerable<ITagSpan<DocCommentGlyphTag>> GetTags(NormalizedSnapshotSpanCollection spans)
        {
            // Only emit tags when the Pro glyph feature is active
            if (!RenderDocOptions.Instance.EffectiveGlyphToggle) yield break;

            var snapshot = spans[0].Snapshot;
            int lineCount = snapshot.LineCount;
            int i = 0;

            while (i < lineCount)
            {
                var line = snapshot.GetLineFromLineNumber(i);
                if (!DocLineRegex.IsMatch(line.GetText())) { i++; continue; }

                // Collect entire block
                int blockStart = i;
                while (i < lineCount && DocLineRegex.IsMatch(snapshot.GetLineFromLineNumber(i).GetText())) i++;
                int blockEnd = i - 1;

                var firstLine = snapshot.GetLineFromLineNumber(blockStart);
                var lastLine  = snapshot.GetLineFromLineNumber(blockEnd);
                var blockSpan = new SnapshotSpan(snapshot,
                    Span.FromBounds(firstLine.Start, lastLine.End));

                // Tag on the first line only
                var tagSpan = new SnapshotSpan(snapshot, firstLine.Start, firstLine.Length);
                if (spans.IntersectsWith(new NormalizedSnapshotSpanCollection(tagSpan)))
                    yield return new TagSpan<DocCommentGlyphTag>(tagSpan, new DocCommentGlyphTag(blockSpan));
            }
        }

        private void OnBufferChanged(object sender, TextContentChangedEventArgs e)
            => TagsChanged?.Invoke(this, new SnapshotSpanEventArgs(
                new SnapshotSpan(e.After, 0, e.After.Length)));

        private void OnSettingsChanged(object sender, EventArgs e)
            => TagsChanged?.Invoke(this, new SnapshotSpanEventArgs(
                new SnapshotSpan(_buffer.CurrentSnapshot, 0, _buffer.CurrentSnapshot.Length)));

        public void Dispose()
        {
            _buffer.Changed -= OnBufferChanged;
            SettingsChangedBroadcast.SettingsChanged -= OnSettingsChanged;
        }
    }

    // ── Tagger provider ───────────────────────────────────────────────────────────

    [Export(typeof(ITaggerProvider))]
    [ContentType("CSharp")]
    [ContentType("Basic")]
    [ContentType("FSharp")]
    [ContentType("C/C++")]
    [TagType(typeof(DocCommentGlyphTag))]
    internal sealed class DocCommentGlyphTaggerProvider : ITaggerProvider
    {
        public ITagger<T> CreateTagger<T>(ITextBuffer buffer) where T : ITag
        {
            return buffer.Properties.GetOrCreateSingletonProperty(
                typeof(DocCommentGlyphTagger),
                () => new DocCommentGlyphTagger(buffer)) as ITagger<T>;
        }
    }

    // ── Glyph factory ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Produces the WPF toggle button shown in the left margin for each doc-comment block.
    /// Clicking it calls <see cref="DocCommentToggleState.Toggle"/> for the block span,
    /// then broadcasts a settings-changed event so the adornment tagger invalidates.
    /// </summary>
    internal sealed class DocCommentGlyphFactory : IGlyphFactory
    {
        private readonly IWpfTextView _view;

        public DocCommentGlyphFactory(IWpfTextView view) { _view = view; }

        public UIElement GenerateGlyph(IWpfTextViewLine line, IGlyphTag tag)
        {
            if (!(tag is DocCommentGlyphTag glyphTag)) return null;
            if (!RenderDocOptions.Instance.EffectiveGlyphToggle) return null;

            bool isRendered = !DocCommentToggleState.IsHidden(glyphTag.BlockSpan);

            var btn = new Border
            {
                Width  = 14,
                Height = 14,
                CornerRadius = new CornerRadius(2),
                Background   = new SolidColorBrush(
                    isRendered
                        ? Color.FromArgb(200, 190, 110, 240)
                        : Color.FromArgb(100, 100, 100, 100)),
                Cursor = Cursors.Hand,
                ToolTip = isRendered ? "Hide rendered comment (click to edit XML)"
                                     : "Show rendered comment",
                Child = new TextBlock
                {
                    Text = isRendered ? "●" : "○",
                    FontSize = 9,
                    Foreground = Brushes.White,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center
                }
            };

            btn.MouseLeftButtonUp += (s, e) =>
            {
                DocCommentToggleState.Toggle(glyphTag.BlockSpan);
                // Invalidate so the tagger re-evaluates visibility
                SettingsChangedBroadcast.RaiseSettingsChanged();
                e.Handled = true;
            };

            return btn;
        }
    }

    // ── Glyph factory provider ────────────────────────────────────────────────────

    [Export(typeof(IGlyphFactoryProvider))]
    [Name("DocCommentGlyphFactory")]
    [ContentType("CSharp")]
    [ContentType("Basic")]
    [ContentType("FSharp")]
    [ContentType("C/C++")]
    [TagType(typeof(DocCommentGlyphTag))]
    [TextViewRole(PredefinedTextViewRoles.Document)]
    [Order(Before = "VsTextMarker")]
    internal sealed class DocCommentGlyphFactoryProvider : IGlyphFactoryProvider
    {
        public IGlyphFactory GetGlyphFactory(IWpfTextView view, IWpfTextViewMargin margin)
            => new DocCommentGlyphFactory(view);
    }

    // ── Per-block toggle state ────────────────────────────────────────────────────

    /// <summary>
    /// Tracks which doc-comment blocks have been manually hidden via the glyph button.
    /// Key: the text of the first line of the block (stable enough for a session).
    /// </summary>
    public static class DocCommentToggleState
    {
        // Using the span's start position as a session-level key.
        // On buffer edits the positions shift, so hidden state intentionally resets — that's fine.
        private static readonly HashSet<int> _hiddenStarts = new HashSet<int>();

        public static bool IsHidden(SnapshotSpan blockSpan)
            => _hiddenStarts.Contains(blockSpan.Start.Position);

        public static void Toggle(SnapshotSpan blockSpan)
        {
            int pos = blockSpan.Start.Position;
            if (_hiddenStarts.Contains(pos)) _hiddenStarts.Remove(pos);
            else _hiddenStarts.Add(pos);
        }

        public static void Clear() => _hiddenStarts.Clear();
    }
}
